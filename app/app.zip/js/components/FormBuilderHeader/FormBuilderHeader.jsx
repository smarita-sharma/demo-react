import React from 'react';

const Header = () =>
  <div>
    <div className="header-wrap">
      <header className="header">
        <nav className="nav">
          <ul>
            <li>
              <a className="back-btn" href="https://demo-us.mybahmni.org/bahmni/home/#/dashboard">

              </a>
            </li>
          </ul>
        </nav>
      </header>
    </div>
  </div>;

export default Header;
